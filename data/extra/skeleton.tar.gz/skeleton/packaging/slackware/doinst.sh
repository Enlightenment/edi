# Stuff done after package installation
